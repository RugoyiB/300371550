// get the date from the input field
function getDate() {
    setInterval("runClock()",1000)

    var i =0;
    var bdd = document.getElementById("birthday");
}

var bdd = new Date(document.getElementById("birthday"));

// start the countdown
function start() {
        
    var now = new Date();
    var distance = now - bdd;

    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hrs = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var mins = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var secs = Math.floor((distance % (1000 * 60)) / 1000);

    document.getElementById('days').innerText = days
    document.getElementById('hrs').innerText = hrs
    document.getElementById('mins').innerText = mins
    document.getElementById('secs').innerText = secs

    if (distance<0) {
        document.getElementById('demo').alert = 'Date is Expired';
    }
}
start() 
    // Set the date we're counting down to

    // Update the count down every 1 second

        // Get today's date and time

        // Find the distance between now and the count down date

        // Time calculations for days, hours, minutes and seconds

        // Output the result in an element with id="demo"

        // If the count down is over, write some text 
        


